// Essa biblioteca contém toda rotina para leitura de JSON externo em JS puro
function logStatus($origem, $mensagem){
	console.log($origem+$mensagem);
}

function injetaMensagem($conteudo, $alvo, $preTag, $posTag, $pedido){
					var caixaDeMensagem = "" ; // Cria variável vazia para concatenar novo conteúdo HTML na menagem
					var autor = "" ; // prepara nome de usuário para tratamento, incluindo, abrir imagens

					// Executa loop até que se encontre o valor '¨$$end' e termina de caixaDeMensagemr os objetos
					for (var i = 0; objeto.dadosRecebidos[i].usuario != '¨$$end'; i++) {
						// $preTag e $posTag insere novos HTMLs
						var usuarioAutor = objeto.dadosRecebidos[i].usuario; // Prepara variável para declarar o autor
						var fotoPerfil   = '<img src="img/'+usuarioAutor+'.jpg" width="40px" height="40px" id="fotoDePerfil">';
						var mensagemAutor = '<i>"'+objeto.dadosRecebidos[i].mensagem+'</i>"';
						
						var mensagemInjetada = $preTag+fotoPerfil+mensagemAutor+$posTag; // Mensagem formatada em html


						var caixaDeMensagem = caixaDeMensagem + mensagemInjetada ;
						
						mensagemConfig.push(objeto.dadosRecebidos[i].usuario); // insere nova informação na matriz
						
					}
					document.getElementById($alvo).innerHTML = caixaDeMensagem; // insere objetos formatados em HTML na id alvo

					
				}


