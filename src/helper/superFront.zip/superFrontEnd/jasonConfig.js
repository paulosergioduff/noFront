var hardware = "http://localhost/"; // Configura aonde estão os recursos de hardware, como servidor, vídeos, fotos, etc
var mensagemConfig = []; // Prepara array para injetar mensagens do back-end em div. Função exercida em outra pag.
var caixaExterna = hardware+'superFrontEnd/'; // Prepara variável de recursos externos caso servidor saia do ar
// Caixa de mensagens e formulários de envio padrão para usar dentro do sistema
var caixaDeEnvioPadrao = '<textarea cols="80"  id="mensagem" name="mensagem"></textarea><input type="submit" value="→" id="enviarBotao" onClick="enviaMensagem()">';
var caixaDeMensagemPadrao = '<iframe src="caixaDeMensagens.html" height="100%" width="100%" frameborder="0">';