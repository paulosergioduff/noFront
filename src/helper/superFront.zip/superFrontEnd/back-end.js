// Insere conteúdo json dentro de variável para usar no sistema, oriundo de back-end
var dadosRecebidos = '{"dadosRecebidos":[' +
			'{"usuario":"joao","mensagem":"Minha primeira mensagem..." },' +
			'{"usuario":"marina","mensagem":"Tamo junto xxyy3!" },' +
			'{"usuario":"¨$$end","mensagem":"Eu também" },' +
			'{"usuario":"end","mensagem":"end" }]}';

