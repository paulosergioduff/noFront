function enviaMensagem(){ // Função  para envio de mensagem com reescrita de interface
	var mensagemCapturada = window.document.getElementById('mensagem').value; // Pega valor da caixa de mensagem
	console.log(mensagemCapturada); // Envia para console resultado
	// Usa variáveis do sistema para rescrever interface: 
		window.document.getElementById('console').innerHTML = '<iframe src="'+hardware+'retorno.php?msg='+mensagemCapturada+'" >';
		window.document.getElementById('mensagens').innerHTML = '<iframe src="'+caixaExterna+'caixaDeMensagens.html" height="100%" width="100%" frameborder="0">';
		window.document.getElementById('caixaEnvioDeMensagem').innerHTML = caixaDeEnvioPadrao;

	document.centralForm.mensagem.focus(); // Mantém o foco no formulário de envio
	}	





